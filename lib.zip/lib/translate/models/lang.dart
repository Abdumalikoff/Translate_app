class Lang {
  final String code;
  final String label;
  const Lang(this.code, this.label);
}
