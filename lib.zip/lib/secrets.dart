class Secrets {
  static const yandexApiKey = 'AQVN3W0WNIzNe-ov0ZSzjIolDl1ffmgi3fMp7Z20';
  static const yandexFolderId = 'b1gobc0rgto94hdh7dt4';
}
